function UseRedTodo() {
  return (
    <div>
      <h2>Todo App using Use reducer</h2>
    </div>
  );
}

export default UseRedTodo;
