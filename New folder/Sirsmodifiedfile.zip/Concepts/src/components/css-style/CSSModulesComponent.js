import React from "react";
import styles from "./styles.module.css";
function CSSModulesComponent() {
  return (
    <>
      <h1 className={styles.header}> hello virat</h1>
    </>
  );
}
export default CSSModulesComponent;
