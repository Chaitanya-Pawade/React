function Child({ count1 }) {
  console.log("changeOne");
  return <div>{<h2>{count1}</h2>}</div>;
}

export default Child;
