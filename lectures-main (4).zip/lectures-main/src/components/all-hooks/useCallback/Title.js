import React from 'react'

function Title() {
    console.log('Title Called');
    return (
        <div>Simple Example for useCallback Hook</div>
    )
}

export default Title