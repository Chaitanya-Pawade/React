import CompE from './CompE'
import CompB from './CompB'

function CompC() {
    return (
        <>
            <CompE />
            <CompB />
        </>
    )
}

export default CompC





